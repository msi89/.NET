# How to record a video with C# and AForge

This application is an example on how to record a video with C# using AForge library. 

You can watch the related video on Youtube: https://www.youtube.com/watch?v=Wje_qSW9xZ8
